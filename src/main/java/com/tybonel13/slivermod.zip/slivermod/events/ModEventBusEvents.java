package com.tybonel13.slivermod.events;

import com.tybonel13.slivermod.Slivers;
import com.tybonel13.slivermod.entity.ModEntityTypes;
import com.tybonel13.slivermod.entity.custom.SliverEntity;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = Slivers.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD)
public class ModEventBusEvents {
    @SubscribeEvent
    public static void addEntityAttributes(EntityAttributeCreationEvent event) {
        event.put(ModEntityTypes.SLIVER.get(), SliverEntity.setCustomAttributes().create());
    }
}
