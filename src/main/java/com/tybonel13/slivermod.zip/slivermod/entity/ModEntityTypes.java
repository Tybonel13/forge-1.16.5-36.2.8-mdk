package com.tybonel13.slivermod.entity;

import com.tybonel13.slivermod.entity.custom.SliverEntity;
import net.minecraft.entity.EntityClassification;
import net.minecraft.entity.EntityType;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import com.tybonel13.slivermod.Slivers;

public class ModEntityTypes {
    public static DeferredRegister<EntityType<?>> Entity_TYPES
            = DeferredRegister.create(ForgeRegistries.ENTITIES, Slivers.MOD_ID);

    public static final RegistryObject<EntityType<SliverEntity>> SLIVER =
            Entity_TYPES.register("sliver", () -> EntityType.Builder.create(SliverEntity::new,
                    EntityClassification.MONSTER).size(1f, 3f)
                    .build(new ResourceLocation(Slivers.MOD_ID, "sliver").toString()));

    public static void register(IEventBus eventBus) {
        Entity_TYPES.register(eventBus);
    }
}
