package com.tybonel13.slivermod.entity.render;

import com.tybonel13.slivermod.Slivers;
import com.tybonel13.slivermod.entity.custom.SliverEntity;
import com.tybonel13.slivermod.entity.model.SliverModel;
import net.minecraft.client.renderer.entity.EntityRendererManager;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.util.ResourceLocation;

public class SliverRenderer extends MobRenderer<SliverEntity, SliverModel<SliverEntity>>
{
    protected static final ResourceLocation TEXTURE =
            new ResourceLocation(Slivers.MOD_ID, "textures/entity/sliver.png");

    public SliverRenderer(EntityRendererManager renderManagerIn) {
        super(renderManagerIn, new SliverModel<>(), 0.7F);
    }

    @Override
    public ResourceLocation getEntityTexture(SliverEntity entity) {
        return TEXTURE;
    }
}
